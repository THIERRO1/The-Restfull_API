package auca.ac.rw.restfullApiAssignment.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import auca.ac.rw.restfullApiAssignment.modal.Product;
import auca.ac.rw.restfullApiAssignment.repository.ProductRepository;

@Service
public class ProductService {

    @Autowired
    private ProductRepository proRepository;

    public String saveProduct(Product product) {
        boolean productExists = proRepository.existsById(product.getId());
        if (productExists) {
            return "Product already exists";
        } else {
            proRepository.save(product);
            return "Product saved successfully";
        }
    }

    public List<Product> getAllProducts() {
        return proRepository.findAll();
    }

    public Optional<Product> getProductById(Long id) {
        return proRepository.findById(id);
    }

    public Optional<Product> updateProduct(Long id, Product updatedProduct) {
        return proRepository.findById(id).map(existingProduct -> {
            existingProduct.setName(updatedProduct.getName());
            existingProduct.setDescription(updatedProduct.getDescription());
            existingProduct.setPrice(updatedProduct.getPrice());
            existingProduct.setCategory(updatedProduct.getCategory());
            existingProduct.setStockQuantity(updatedProduct.getStockQuantity());
            existingProduct.setBrand(updatedProduct.getBrand());
            return proRepository.save(existingProduct);
        });
    }

    public boolean deleteProduct(Long id) {
        if (!proRepository.existsById(id)) {
            return false;
        }
        proRepository.deleteById(id);
        return true;
    }
    
}
